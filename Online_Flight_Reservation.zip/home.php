<?php 
include 'config.php';
?> 

<!DOCTYPE Tutorial - work> 
<html>  
<head> 
<link rel="stylesheet" href="web.css">
<title> Log-in </title>  
<h2   style="background-image: url('homepage.png');background-repeat: no-repeat;background-size: 250px 250px;" class="h" align="center"  >Welcome to Home </h2>
</head> 

<body  id="b"> 
<div style="background-image: url('Airline.png');background-repeat: no-repeat;background-size: 1000px 500px;"  id="dd">  

<form action="home.php" method="POST" align="center"> 

<b>


<a href="booking.php">   <input name ="booking" type="button" id="butt" value="Book Ticket Now">  </input> </a>
<a href="history.php">   <input name="history" type="button"  id="butt" value="History View" > </input>   </a>  
<a href="cancel.php">    <input name="cancel"  type="button"  id="butt" value="Cancel Ticket" > </input>   </a> 
 <input name="logout" type="submit" id="logout" value="Log-Out" > </input> 

<?php 
     if(isset($_POST['logout'])){
		 echo "
           <script> 
                   alert('You are successfully Log-Out. ');
				   window.location.href = 'login.php';
		   </script>
 

		 ";
		 
	 } else{}

?>

</form>
</div>
</body>
</html>